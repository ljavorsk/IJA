
javac -d build -cp ".:junit-platform-console-standalone-1.6.0.jar" ija/ija2019/homework2/Homework2Test.java

java -jar junit-platform-console-standalone-1.6.0.jar -cp "build" -c ija.ija2019.homework2.Homework2Test
